# python-aws-code

Connect to a S3 and list all buckets; Add a new bucket and upload file to it
python s3.py

Connect to S3 and load a multipart file greater than 100 MB
python s3-multipartload.py

Connect to EC2 instance and list all instances
python ec2.py
